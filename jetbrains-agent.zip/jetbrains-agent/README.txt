 ========================================================================
 =======    Jetbrains Activation Code And License Server Crack    =======
 =======                     https://zhile.io                     =======
 =======              v2.1.1, Build Date: 2019-05-29              =======
 ========================================================================

 *** 如果你下载的jetbrains-agent.jar小于1M，肯定是没有下载完全（可对照sha1sum.txt）。***
 *** 请先一定仔细阅读本文档！一定通过IDE菜单编辑javaagent参数，别瞎TM在bin目录下改！！！***
 *** 请先一定仔细阅读本文档！一定通过IDE菜单编辑javaagent参数，别瞎TM在bin目录下改！！！***
 *** 请先一定仔细阅读本文档！一定通过IDE菜单编辑javaagent参数，别瞎TM在bin目录下改！！！***
 *** 请先一定仔细阅读本文档！一定通过IDE菜单编辑javaagent参数，别瞎TM在bin目录下改！！！***
 *** 请先一定仔细阅读本文档！一定通过IDE菜单编辑javaagent参数，别瞎TM在bin目录下改！！！***
 *** 请先一定仔细阅读本文档！一定通过IDE菜单编辑javaagent参数，别瞎TM在bin目录下改！！！***
 *** 请先一定仔细阅读本文档！一定通过IDE菜单编辑javaagent参数，别瞎TM在bin目录下改！！！***
 *** 请先一定仔细阅读本文档！一定通过IDE菜单编辑javaagent参数，别瞎TM在bin目录下改！！！***
 *** 请先一定仔细阅读本文档！一定通过IDE菜单编辑javaagent参数，别瞎TM在bin目录下改！！！***
 *** 请先一定仔细阅读本文档！一定通过IDE菜单编辑javaagent参数，别瞎TM在bin目录下改！！！***
 *** 可以参考文件夹内：javaagent_sample.png ***

 Usage:
 0. Download the zip package and get jetbrains-agent.jar first
    Download page: https://zhile.io/2018/08/17/jetbrains-license-server-crack.html
 1. Run the IDE and evalutate for free
 2. Click IDE menu "Configure" or "Help" -> "Edit Custom VM Options..."
    See: https://intellij-support.jetbrains.com/hc/en-us/articles/206544869
 3. Append -javaagent:/absolute/path/to/jetbrains-agent.jar to end line
    eg:
      mac:      -javaagent:/Users/neo/jetbrains-agent.jar
      linux:    -javaagent:/home/neo/jetbrains-agent.jar
      windows:  -javaagent:C:\Users\neo\jetbrains-agent.jar
    Rescue: https://intellij-support.jetbrains.com/hc/en-us/articles/206544519
 4. Restart IDE
 5. Click IDE menu "Help" -> "Register..." or "Configure" -> "Manage License..."
    Support "License server" and "Activation code":
    1). Entry license server address: http://jetbrains-license-server (maybe autofill)
        Or click the button: "Discover Server" to fill automaticly
    2). Active offline with the activation code file: ACTIVATION_CODE.txt
        If the activation window always pops up(error 1653219), remove jetbrains' domains from hosts file
        If you need a custom license name, visit: https://zhile.io/custom-license.html

 使用方法:
 0. 先下载压缩包解压后得到jetbrains-agent.jar，把它放到你认为合适的文件夹内。
    下载页面：https://zhile.io/2018/08/17/jetbrains-license-server-crack.html
 1. 启动你的IDE，如果上来就需要注册，选择：试用（Evaluate for free）进入IDE
 2. 点击你要注册的IDE菜单："Configure" 或 "Help" -> "Edit Custom VM Options ..."
    如果提示是否要创建文件，请点"Yes"。
    参考文章：https://intellij-support.jetbrains.com/hc/en-us/articles/206544869
 3. 在打开的vmoptions编辑窗口末行添加：-javaagent:/absolute/path/to/jetbrains-agent.jar
    一定要自己确认好路径(不要使用中文路径)，填错会导致IDE打不开！！！最好使用绝对路径。
	一个vmoptions内只能有一个-javaagent参数。
    示例:
      mac:      -javaagent:/Users/neo/jetbrains-agent.jar
      linux:    -javaagent:/home/neo/jetbrains-agent.jar
      windows:  -javaagent:C:\Users\neo\jetbrains-agent.jar
    如果还是填错了，参考这篇文章编辑vmoptions补救：
    https://intellij-support.jetbrains.com/hc/en-us/articles/206544519
 4. 重启你的IDE。
 5. 点击IDE菜单 "Help" -> "Register..." 或 "Configure" -> "Manage License..."
    支持两种注册方式：License server 和 Activation code:
    1). 选择License server方式，地址填入：http://jetbrains-license-server （应该会自动填上）
        或者点击按钮："Discover Server"来自动填充地址。
    2). 选择Activation code方式离线激活，请使用：ACTIVATION_CODE.txt 内的注册码激活
        如果激活窗口一直弹出（error 1653219），请去hosts文件里移除jetbrains相关的项目
        如果你需要自定义License name，请访问：https://zhile.io/custom-license.html

 本项目在最新2019.1.3上测试通过。
 理论上适用于目前Jetbrains全系列所有新老版本（这句话是瞎说的，如有问题请给我issue或进QQ群：30347511讨论）。
 IDE升级会从旧版本导入以上设置，导入配置后可能提示未注册（因为刚导入的vmoptions未生效），直接重启IDE即可，无需其他操作。


 本项目只做学习研究之用，不得用于商业用途！
 若资金允许，请点击 [https://www.jetbrains.com/idea/buy/] 购买正版，谢谢合作！
 学生凭学生证可免费申请 [https://sales.jetbrains.com/hc/zh-cn/articles/207154369-学生授权申请方式] 正版授权！
 创业公司可5折购买 [https://www.jetbrains.com/shop/eform/startup] 正版授权！

